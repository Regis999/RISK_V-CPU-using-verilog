
module mux2x1 (
    input A,
    input B,
    input S,
    input clk,
    output reg Y
);

always @(posedge clk)
begin
    if (S == 1'b0)
        Y <= A;
    else
        Y <= B;
end

endmodule
