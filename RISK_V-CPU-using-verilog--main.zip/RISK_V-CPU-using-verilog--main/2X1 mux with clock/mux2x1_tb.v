
`timescale 1ns/1ps

module mux2x1_tb;

reg A, B, S, clk;
wire Y;

// Instantiate MUX
mux2x1 uut (
    .A(A),
    .B(B),
    .S(S),
    .clk(clk),
    .Y(Y)
);

// Clock generation
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Test inputs
initial begin

    $monitor("Time=%0t A=%b B=%b S=%b clk=%b Y=%b",
              $time, A, B, S, clk, Y);

    A=0; B=0; S=0;
    #10;

    A=1; B=0; S=0;
    #10;

    A=0; B=1; S=1;
    #10;

    A=1; B=1; S=0;
    #10;

    A=0; B=1; S=1;
    #10;

    $finish;
end

endmodule
