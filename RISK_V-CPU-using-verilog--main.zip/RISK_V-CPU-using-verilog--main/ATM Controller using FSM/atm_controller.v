
module atm_controller (
    input clk,
    input reset,
    input card,
    input pin_valid,
    input withdraw,
    input balance_ok,
    output reg enter_pin,
    output reg check_balance,
    output reg dispense_cash,
    output reg transaction_done,
    output reg error
);

// State declaration
parameter IDLE       = 3'b000,
          PIN_CHECK  = 3'b001,
          BALANCE    = 3'b010,
          WITHDRAW   = 3'b011,
          SUCCESS    = 3'b100,
          FAILURE    = 3'b101;

// Present and next state
reg [2:0] present_state, next_state;

// Sequential logic
always @(posedge clk or posedge reset)
begin
    if (reset)
        present_state <= IDLE;
    else
        present_state <= next_state;
end

// Next state logic
always @(*)
begin
    next_state = present_state;

    case (present_state)

        IDLE:
            if (card)
                next_state = PIN_CHECK;

        PIN_CHECK:
            if (pin_valid)
                next_state = BALANCE;
            else
                next_state = FAILURE;

        BALANCE:
            if (withdraw && balance_ok)
                next_state = WITHDRAW;
            else
                next_state = FAILURE;

        WITHDRAW:
            next_state = SUCCESS;

        SUCCESS:
            next_state = IDLE;

        FAILURE:
            next_state = IDLE;

        default:
            next_state = IDLE;

    endcase
end

// Output logic
always @(*)
begin
    enter_pin = 0;
    check_balance = 0;
    dispense_cash = 0;
    transaction_done = 0;
    error = 0;

    case (present_state)

        IDLE:
            begin
            end

        PIN_CHECK:
            enter_pin = 1;

        BALANCE:
            check_balance = 1;

        WITHDRAW:
            dispense_cash = 1;

        SUCCESS:
            transaction_done = 1;

        FAILURE:
            error = 1;

        default:
            begin
            end

    endcase
end

endmodule
