
module atm_controller_tb;

reg clk, reset;
reg card, pin_valid, withdraw, balance_ok;

wire enter_pin, check_balance;
wire dispense_cash, transaction_done, error;

// Instantiate ATM controller
atm_controller uut (
    .clk(clk),
    .reset(reset),
    .card(card),
    .pin_valid(pin_valid),
    .withdraw(withdraw),
    .balance_ok(balance_ok),
    .enter_pin(enter_pin),
    .check_balance(check_balance),
    .dispense_cash(dispense_cash),
    .transaction_done(transaction_done),
    .error(error)
);

// Clock generation
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Test sequence
initial begin

    reset = 1;
    card = 0;
    pin_valid = 0;
    withdraw = 0;
    balance_ok = 0;

    #10 reset = 0;

    // Insert ATM card
    #10 card = 1;

    // Enter correct PIN
    #10 pin_valid = 1;

    // Request withdrawal with sufficient balance
    #10 withdraw = 1;
    balance_ok = 1;

    #40;

    // Reset for next test
    reset = 1;
    #10 reset = 0;

    // Insert card with incorrect PIN
    card = 1;
    #10 pin_valid = 0;

    #30;

    $finish;
end

// Display output
initial begin
    $monitor("Time=%0t | Card=%b PIN=%b | Cash=%b Done=%b Error=%b",
             $time, card, pin_valid,
             dispense_cash, transaction_done, error);
end

endmodule
