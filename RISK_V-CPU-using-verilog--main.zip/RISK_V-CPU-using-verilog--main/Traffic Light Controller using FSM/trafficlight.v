
module traffic_light_fsm (
    input clk,
    input reset,
    output reg red,
    output reg yellow,
    output reg green
);

// State declaration
parameter RED_STATE    = 2'b00,
          GREEN_STATE  = 2'b01,
          YELLOW_STATE = 2'b10;

// Present state and next state
reg [1:0] present_state, next_state;

// State transition (Sequential logic)
always @(posedge clk or posedge reset)
begin
    if (reset)
        present_state <= RED_STATE;
    else
        present_state <= next_state;
end

// Next state logic
always @(*)
begin
    case (present_state)

        RED_STATE:
            next_state = GREEN_STATE;

        GREEN_STATE:
            next_state = YELLOW_STATE;

        YELLOW_STATE:
            next_state = RED_STATE;

        default:
            next_state = RED_STATE;

    endcase
end

// Output logic
always @(*)
begin
    red = 0;
    yellow = 0;
    green = 0;

    case (present_state)

        RED_STATE:
            red = 1;

        GREEN_STATE:
            green = 1;

        YELLOW_STATE:
            yellow = 1;

        default:
            red = 1;

    endcase
end

endmodule
