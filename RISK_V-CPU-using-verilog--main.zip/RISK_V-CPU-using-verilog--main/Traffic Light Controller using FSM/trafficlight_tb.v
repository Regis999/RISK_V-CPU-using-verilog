
module traffic_light_fsm_tb;

reg clk, reset;
wire red, yellow, green;

// Instantiate DUT
traffic_light_fsm uut (
    .clk(clk),
    .reset(reset),
    .red(red),
    .yellow(yellow),
    .green(green)
);

// Clock generation
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Test sequence
initial begin
    reset = 1;
    #10;
    reset = 0;

    #100;
    $finish;
end

// Monitor output
initial begin
    $monitor("Time=%0t | Red=%b Yellow=%b Green=%b",
              $time, red, yellow, green);
end

endmodule
